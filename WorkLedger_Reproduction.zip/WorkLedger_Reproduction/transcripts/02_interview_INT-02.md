# Interview 2 — Screens, atomised work, and the cost of a token

**Project:** WorkLedger — China Spring interview series
**Interview code:** INT-02
**Recording date:** 29 April 2026 (file dated 30 April 2026)
**Duration:** approx. 60 minutes
**Participants:** R1 (chairman and general manager), R2 (interviewer), R3 (a second participant; speaks as an operations insider)
**Other voices:** R4 (a further participant in the room, not otherwise identified) and R5 (voice-over from a company video played during the visit, 31:38–35:22).
**Language:** Mandarin. This is an edited English translation.
**Transcription:** machine-generated and lightly corrected. `[unclear]` marks passages whose meaning could not be recovered; `[note]` marks editorial reconstruction. Speaker turns are preserved one for one; only repetition and false starts within a turn were removed.
**Anonymisation:** the company is referred to as China Spring; individuals appear as R1–R5.

## Summary

An hour of walking through the plant and the systems it runs on. R1 begins with the rules he sets—fifteen-minute response times, performance instead of headcount—and demonstrates the monitoring screens: tagged events, a calendar of green and broken lines, electricity by tariff band. He explains why he uses a KPI as a check rather than a whip, and why observation stops at the hand rather than reaching the face. The tour moves to retrofits (PLC monitoring, 5G meters, two or three million RMB), the reasons for building equipment in-house, and the joint venture whose profit he controls. He then shows a test machine, prices a line at close to 20 million RMB, and describes a competitor's German line. A company video presents an R&D assistant that generates drawings from parameters; R1 compares models and tracks token spending. He develops an argument about continuous thought, then turns to process re-engineering: series into parallel, the atomisation of cost, and why R&D must transform.

## Transcript

### 1. The fifteen-minute rule (00:00–01:28)

**R1 (00:00)** — If I am busy, you need to be able to state exactly how much is required—otherwise it just becomes this department giving the company an answer. That is how it works with us now. We set a rule: if a machine breaks down, the response has to come within fifteen minutes. If people cannot do it, then analyse whether it was slackness, whether it was material preparation, or what the problem actually was. If it is not simply a question of hands, then we change—we use this to pull things along, to manage dynamically. Otherwise it is like a government office: you have three posts, I have four posts, and you control the posts, and all day you are coming to see me. The energy goes into that kind of ineffective activity. Instead we look at actual performance. Through this data analysis—if you are short, then I will pair you, and I may even suggest that from now on you do not do it this way.

**R2 (00:54)** — You have to know this. Right, right.

**R1 (00:56)** — So through all this—the thing everyone in the factory does every day: why does it have to be every day? Because if they do not work around the data, it turns into more talk, more familiarity, more essays. We let the two of them find the problems and solve the problems. As things stand, we are not necessarily the best, but we—

**R2 (01:24)** — How do you motivate them to feed it every day? How do you motivate them to feed the data every day?

**R1 (01:28)** — There is no extra reward; this is the incentive in itself. I bring it with me, and I require that at meetings they all speak to me through it. I looked at it, and he asked one question—mainly, you open that, and then it becomes clear. But this has to go through a process. If the employees under me already have the awareness, there is no need for [unclear: the routine]—no, I still want root-cause analysis. As for how to push it through, some of it I will take with me. That is roughly how I see it.

### 2. What the screen shows (02:01–04:22)

**R1 (02:01)** — Let us open one. You can see who the operator is now, and the current running status—we set up some monitoring. There are several kinds: some for safety, and some on the key [parameters]. Because in future, if something does go wrong, we need this kind of traceability to support the brand problem. Say [a colleague] wants to do something—no problem. If we find an anomaly here and at the same time a quality problem, we can focus more easily. And all of these things carry tags.

**R1 (02:41)** — Look at that calendar. What is a tag? An example: let me stretch this out. Zoom in a bit. Say ten days. Yesterday, you said? You can look at yesterday. Green means normal production; all these lines above mark a break.

**R1 (03:07)** — Some of it can be maintained automatically at the end—for example, that someone is on shift, or on duty. Some still has to be judged by the team leader. All of it is tagged. If I click this open, I know that the video will drop straight away, this part of the video. So all of it is representative. Then, how many times it happened in total—

**R2 (03:33)** — It needs analysis.

**R1 (03:34)** — Then they come and analyse: is this one too long? Why is this place like this? That is how we get people to do it. Otherwise energy and content—this is the trend. There should be that kind of monitoring screen, right?

**R3 (04:01)** — It is here.

**R3 (04:10)** — Yes, we only provide the display. That is, that table.

**R1 (04:15)** — Then over here we have the review centre's—

**R3 (04:22)** — Something like, for each type of forklift, [unclear: its usage].

### 3. The KPI as a check, not a whip (04:26–06:43)

**R1 (04:26)** — Usage. The electricity consumed between them—we should find a way to make that as low as possible, fewer categories, and more of it in the valley [note: the off-peak tariff band]. Then use that as the KPI and keep optimising. But this KPI—our company does not do KPI; we rarely use it as a reference. The group does protect us strongly, but we rarely do it. The philosophy is this: strong KPI assessment also becomes a fault [note: an excess, something that overshoots]. All I need is the data. I treat the KPI as a check—is my path right? Right.

**R1 (05:17)** — For example, I want to make ten million this year; at the end of the year I look at whether I made money. That is right. But day to day I do not manage that, because over the year I should invest in and finish the things that ought to be done; at the end of the year I just take a look. Of course I am not saying I do not monitor. At each base, how much each day's output earns—I know that every day. The operations situation, I also—this is through WeCom's smart sheets. So it is dynamic, day by day. And when I travel now I rarely take my phone; I take the laptop, and basically I always have [it].

**R2 (06:07)** — On the phone—there is an app you can check, right?

**R1 (06:09)** — Yes, this is my operations bulletin. It is daily, and it can be drilled into and pushed down. Not deep enough yet, but this—the penetration. And the rest: we now do all of it through these smart sheets and enterprise-type products, and on that point it is quite good. Feishu and DingTalk both have it, but we use WeCom because the sixty-odd people around me all have it.

**R2 (06:41)** — Right, but everyone has DingTalk.

**R1 (06:43)** — Right, right, so we use WeCom. On some features it may not be better, but I think it is the connectivity. This is our information system, roughly. Only a very few issues need human judgement—that is, the quality of the collected data. Quality is where we really accumulate. The earlier part is only cost-reduction analysis. As for our problems: I think this kind of data is still not good enough, and that is what I want to solve. At the moment we can only monitor equipment, not yet the parts.

### 4. Hand and face (07:32–08:00)

**R2 (07:32)** — The granularity is not fine enough.

**R1 (07:35)** — It is like a wife slapping her husband: we can only monitor the hand; we cannot yet get to the face, to that expression.

**R2 (07:46)** — Maybe later.

**R1 (07:48)** — Motion analysis is needed—the deformation of the face, and afterwards whether there is a red mark on the face; that may still need [unclear: refinement].

**R2 (07:57)** — That is what you said the camera vendor can do.

**R1 (08:00)** — [unclear] today we only monitor some hands. Once this is done well, we can do a lot: non-destructive testing, for example; replacing one thing with another—substitution.

### 5. What the retrofit cost (08:17–09:38)

**R2 (08:17)** — A question: is this monitoring end-of-line monitoring, or do you monitor every step?

**R3 (08:26)** — Our worry is that we now split into many types—result, and process. For example, our temperature, the quenching temperature: I observe the highest point in the whole process to monitor it, grabbing that data frequently, then doing one analysis. Then across the whole process, the relation between one step and the next, including time and heating power and some interfaces, and then observe [unclear].

**R2 (09:01)** — But the more monitoring there is, the higher the cost, right?

**R3 (09:05)** — Yes. For this data collection we have spent a great deal of effort: retrofitting equipment for data, the PLC-related monitoring equipment, retrofitting the temperature-measurement equipment, the system equipment, and extending the network architecture.

**R2 (09:18)** — Roughly how much does that kind of retrofit cost?

**R1 (09:21)** — It depends whether you make or buy. We mostly make, so our cost is very low. Others might need [unclear: ten to fifty million]. Yes.

**R2 (09:32)** — I do not know—you must be under ten or twenty million, but a few million must be needed.

**R1 (09:38)** — Ours is about two or three [million]. Including hardware: I have changed even the electricity meters for 5G ones. So I say this is a good age for innovation. I have to take the individual and the common—obviously it is an age of involution, but seen the other way it is an age of innovation. Whatever we buy: that meter used to cost a few thousand each; now it is a few hundred. If I do the maintenance work with my own tools, it is just material cost. If I bring in a company and say, come and do this for me, the cost immediately becomes over a thousand.

### 6. Cheap hardware in an age of involution (10:19–13:19)

**R2 (10:19)** — Still, that is because you have that advantage.

**R1 (10:21)** — That is what we have built up slowly. All these things are done by them; every detail is done inside one [frame]. There is a restaurant next door to us called Simple. We go there often—why? Because we want simplicity and plainness [note: the restaurant's name is the word for "simple"], so we want to go there.

**R2 (10:42)** — The owner can still run a restaurant.

**R1 (10:46)** — There is; he took the initiative—that is good.

**R4 (10:50)** — Refined.

**R2 (10:53)** — It feels good in the hand.

**R1 (10:57)** — Wait—in a moment I will show you the venue set-up. We had name cards made for the meeting, but the cards are small and the logo is on the screen, so that it only works when you walk past—right? We turned one into a phone stand; probably our own employee made it by hand.

**R4 (11:14)** — I think this kind of manufacturing—

**R2 (11:16)** — companies really—

**R4 (11:18)** — have that capability.

**R2 (11:20)** — The hands-on ability—

**R4 (11:22)** — We really cannot manage anything.

**R2 (11:25)** — Do not underestimate ourselves; maybe we have it too. Right.

**R1 (11:28)** — Like this spring.

**R4 (11:29)** — Look—where is this spring from?

**R1 (11:31)** — Not this one; it is from a gearbox.

**R4 (11:33)** — A gearbox.

**R1 (11:34)** — That is because we make stabiliser bars, [unclear: so we] take seriously whether the problem is here or there. Right? This is simpler, and the spring does the same job. Looking at it: the upper coil or the lower coil, what the coil gap is, how it closes—which is better. Convenient. Second, this is also a cultural-creative piece—[unclear: the tea set has a lid], placed over there. This one is ours.

**R2 (12:07)** — This one.

**R1 (12:08)** — These are the places that automatically adjust or scrap, or after the sample is taken.

**R4 (12:13)** — There is a lot of creativity in this.

**R1 (12:15)** — Right, right. Because we always find a way to spend little money; you only have to be attentive in advance. These are the various kinds of monitoring. Before, when we did not monitor, we replaced that. And the whole process was noisy and expensive. So now we do this monitoring—mainly equipment vibration, noise, what has gone wrong. Our maintenance workers intervene proactively; before, you had to wait until it got to [unclear: failure].

**R2 (12:48)** — It is a bit like what we call "treating the illness before it comes" in management: you prevent before you are sick.

**R1 (12:54)** — That is—was it Confucius, or Sun Tzu's Art of War, or Laozi? It is the line that came to us through translation—the Westerners probably said it, so it is a translated line. "The general with no medals is the best general." Otherwise he has to fight until heads are broken and blood flows, the men below him are all dead, and then he is given a first-class battle merit.

**R1 (13:19)** — "The supreme art of war is to attack the plan." For example, with these things of yours—you are over there, and the other side does it naturally. Good, that is roughly what we do. Let us look further down, at the production floor. We will introduce our springs, since we did not get to the site today. Our spring—you will feel there are four [steps]. The four names: forming, heat treatment, strengthening—strengthening by shot peening—then coating. This time we go back to Shanghai, and we say the last year. [unclear: the transcript renders the end of this passage as unrecognisable English]

### 7. The four process steps (14:11–15:38)

**R1 (14:11)** — The screen in that glass room—there is an acceptance check in here. This one. Right.

**R3 (14:19)** — Inside the screen is what the optical inspection gives you.

**R1 (14:21)** — No—is there not a screen inside this room, and several cameras as well? Why do you not point those cameras here? They are over there, are they not? Right. Good.

**R3 (14:33)** — One is the overall layout of our coiling machines.

**R1 (14:41)** — Let us look at the whole thing. First, all of this is real time. This is our—the wire for our joint venture goes in here, is threaded through, into this coiling machine; once one is coiled, it moves on naturally to [unclear: quenching], and after that, at the back, to what we call shot-peening strengthening. Now they may be—[unclear: another English phrase in the transcript].

**R2 (15:15)** — So for making springs, the material that goes into the coiling machine has very high requirements, right?

**R1 (15:22)** — The ingredients.

**R2 (15:23)** — Have to be good. If springs are to be good, the ingredients have to be good. How are we doing on that now—on the ingredients?

**R1 (15:35)** — In fact we use that joint venture.

**R2 (15:38)** — That is how it is done, right?

### 8. The joint venture and the chairman's leverage (15:39–17:04)

**R1 (15:39)** — Because before, we did not have this capability; now we do. But as for this joint venture—I only need to control its profit. I am the chairman, and I would say its profit used to be thirty or fifty million, so I had to find a way to move it, and I moved my joint-venture plan forward. But I think their taking ten million is not a big problem. Because my partner has overseas bases in North America, in Europe, in many places. So I find a way—at present it is equivalent to a fee we pay. When I expand overseas later, we can use his resources.

**R2 (16:24)** — Right—[a colleague] would use it.

**R1 (16:25)** — His resources. If I split with him first, and later he uses his resources—he has not signed yet. [unclear: once you go there, if he dares to do that, I will ask him from here].

**R2 (16:38)** — Right, right.

**R1 (16:40)** — We play the game through this structure. Of course, if you play the game you want the biggest [leverage]. I want insurance.

**R2 (16:47)** — In total you have to pay—

**R1 (16:48)** — Insurance, something like that. What I mean is that through this we first share the returns. Good—what is this? There are a few other products that are more extreme. There is a back office. Right.

**R3 (17:04)** — This back office is enclosed—the whole enclosure; how much [unclear] is needed.

### 9. Building our own equipment (17:16–19:01)

**R1 (17:16)** — This one has just stopped here; I have finished. The development came one by one, in order. Apart from the robots, all this equipment is our own. This equipment we give particular attention to. Why do it? One, speed; the other, confidentiality.

**R1 (17:45)** — We were talking about ideas and methods—why there are so many ideas, and so much difficulty. An example. Long ago, in the early reform period, people said the Wenzhou man has a mind of his own. He does not know whether the napkin box has napkins in it—so what does he do? The Germans are second [unclear: maybe they weigh it], the Japanese—and the Wenzhou man just uses a phone to blow [unclear]. Now think about this idea: if the Japanese and the Americans both recognise it, and once they use their method they can blow the empty one open or make it hot—right? The key is that some of this is innovation at the inner layer, so if we want to do it ourselves, that is how we do it. One problem for us: [a colleague], with us, sometimes international [partners] move a little slowly—the idea has not been implemented here, and my competitor is already using it. Now through these—of course, behind all of it, we have to accelerate. For example, my best—

**R2 (19:00)** — Ahead.

**R1 (19:01)** — And as I was just saying to you: what I want is not the renovation of a whole building. I want employees to know that [unclear] is changing all the time. Then think: as long as my equipment, my data, my operating deployment—including that I am a diffuse, dispersed kind of [unclear]—right, he cannot overtake it. He comes today, and tomorrow there is a change. Today I say, look at whatever you like; tomorrow I have changed it all. That is what we do through this. There are many small details inside; once they have understood these details, they become very fast.

### 10. Top-level design, and selling the second generation (19:42–22:33)

**R2 (19:42)** — But when you are diffuse like this, is there a top-level design in itself?

**R1 (19:47)** — There is; ultimately it has to come back to something traditional. For example, I need to issue new shares [unclear], what the concept is on that side. Also, marketisation has to be used as a kind of risk [note: a discipline imposed from outside]—not some kind of forced difficulty. So now, how do we sell it? Only after you sell it does it become fixed.

**R2 (20:10)** — Which one do you mean selling?

**R1 (20:12)** — Selling equipment—this equipment, right? I have a bit: when I have 2.0, I sell it. And then Chinese military industry.

**R2 (20:18)** — The same concept.

**R1 (20:20)** — In fact the requirement is the same. What I said just now: to do this whole network well you have to deliver performance. And to do the manager [part], you have to set up a university of science and technology. That is other people's method; me thinking about how I would do it—right, that means nothing. What is his model, right? In military industry, once he has it he may already have two generations. Right, two generations. I mean, once I sell it, I will definitely tell you—I also want an order. This trip was good. Last week I went from Germany to Germany—[unclear: one line, assets in Germany].

**R1 (20:54)** — It seems—just now, that sentence, those two—in fact he has equipment, products and so on. We went to look, and it was very clear: the ones who did some scanning for us, including some technologies—they use them too, and they show them to us with a real sense of superiority, because we cannot afford their equipment. One of their conversion machines is twenty or thirty million. What we have here is, say, three to five million for mainland or Taiwanese machines; theirs is German equipment. We could afford it once; now we cannot, so the relationship is still there. Then he said we now have a strategic cooperation, and we will first do a scan. I was startled—I thought I would be able to visit. Afterwards I saw that, first, their basic logic is the same as yours. And after he had finished, I—[unclear]—I said: look at me, your idea is the same as ours. He was like that at the time. Do you know why?

**R4 (21:55)** — Cost—maybe he thinks [unclear: our speed].

**R1 (21:58)** — [unclear: 3D printing]; their speed is 3D. As long as we see it, we will consider it, right?

**R2 (22:07)** — Right.

**R1 (22:09)** — Like the speed of AI and the speed at which I program: once AI is given the programming capability, it will definitely be [unclear: wrong]. Whether it was fast enough before—we are now, and it is not that we see it from far off; we are roughly what you would call each with our own strengths. Including some of our other [products]—but I find that in industrial styling design we still have a problem.

**R2 (22:31)** — So they are this—not this. Right.

**R1 (22:33)** — This meeting—ours—of course we are adjusting now. You see what you just—[unclear]—let us look at the test machine.

### 11. The test machine and the price of a line (22:47–26:23)

**R3 (22:47)** — What is it now?

**R1 (22:54)** — Some of the real characteristics.

**R1 (23:03)** — Thank you. In the city—this is our first-generation test machine, and it is in here, right? That is what it looks like. We were already [trying it] internally at the time, because I require this equipment to have capability, to have looks, and to have thought. Thought needs data accumulation, then the algorithm; and then looks; and then capability—like being beautiful, [unclear]. This is our next one. This one is for selling outside; this one is for our own use. This one is the high configuration—we do not sell the high configuration; we sell them the low configuration.

**R4 (23:51)** — Does this involve going overseas?

**R1 (23:55)** — This generation we have already shipped. This generation is in Uzbekistan. In Uzbekistan they want all of this set; apart from some things we buy in—[unclear]—the rest, the core mechanism design, is ours.

**R4 (24:15)** — How much for a set?

**R1 (24:20)** — It is hard to say exactly. One production line of ours is close to 20 million—everything bought and configured, in RMB.

**R4 (24:27)** — I see.

**R1 (24:29)** — In RMB, we are high input, low output. Not like some electronics industries—low input, [unclear], but high output; one of their lines only needs two or three million, three to five million. We are large-scale equipment, so it is relatively expensive. But that is fine; there is no story. That is, like us now, in contact with the material end: do not be fooled by how many above us do it better—in fact, from the electronics industry, or some of them, even though this investment is now—

**R4 (25:04)** — At present most of the talent.

**R1 (25:06)** — Right now most of the materials can still survive. Most of the electronics—I am not clear.

**R4 (25:11)** — What is fashionable now is asset-heavy companies—[unclear: AI] and that sort of thing.

**R1 (25:17)** — I think later capital will probably not [do that]. It will split into sections: one part is always the hottest, and another part is the technology-based foundation. I am waiting for that day, because then we could list a second time. We were listed before—[unclear: within a larger group]—that object; it was really good then, for so long after it became this. Good. Then this is a spring, then let us look at ours. Of course we still have many manual lines. Then last time—our review yesterday, was it not just like this—the reviewers in the review process: many good reviews now are enabling reviews; it is not that you have to adjust the classification yourself. He said—we told him about this small-order contribution of ours, and then [unclear]—and he was heuristic. He said Rolls-Royce is hand-built, and this is also hand-built.

**R1 (26:23)** — Right—so how do we turn it into high-end customisation? This part is ours—this is our automatic stabiliser-bar line. This one takes account of the environmental oil-smoke effect. Because there is smoke now, we cover it with a fire hood. The general direction is: here a steel-tube machine does the forming; then inside here there is heating on one side—this red-hot part, you see, here is one red-hot—and then it goes through quenching. Then sometimes there is an activity [unclear]. Once it is done, over here it goes into tempering. Tempering removes the [residual stress], so this process you can see clearly.

### 12. The enclosure, the robots, and a video (27:06–31:34)

**R3 (27:06)** — No, no, no.

**R1 (27:07)** — We built one over [unclear: the energy side] that people think was put up for [unclear]; in fact I think it also serves confidentiality. Most of the time it is not even switched on; we use only its transfer chain. Second, taking it apart is a nuisance and it takes up a lot of floor space, so we simply do it. Now, through our own process design, we can charge on both sides [unclear]. That way my energy consumption, compared with new-energy designs and with conventional designs, is two levels better, and the efficiency is a bit higher. In fact I do not need that much time; I cannot—it is equivalent to [unclear]. So in fact, for me the application of technology here has the highest input-output ratio, and it is still the place where—I want to put it a little myself—where a bit of sunshine is enough.

**R1 (28:08)** — This is cold forming. All spring stabiliser bars have cold forming; there is also hot forming. Good—this thing should not be running. Now—go and look at Wuhu; Wugu has hot-formed springs, and [unclear: one line] that is not hot-formed.

**R4 (28:28)** — Are all the monitoring systems from the camera vendor?

**R1 (28:31)** — No, they are no-name brands, transmitted by ourselves. Look, our robots are yellow one moment, red the next, then [unclear]. Right—I was just [talking] with a university classmate.

**R4 (28:43)** — Manufacturing companies are impressive.

**R1 (28:45)** — It all comes down to breaking that necessity. Do you know why? Take the Japanese one, or the Swiss one, or the German one—now the Chinese ones; the logic is the same, it is just that one is Japanese and one speaks German, right? Why should I learn three languages? So I think, once it is like that—in future, if, say, Taiwan builds a brand, I basically just wait for you: when you are losing money, when you fold, I buy you second-hand. On my side [unclear: the work is] clean and tidy, right? Like Sun Tzu, who could even drill the King of Chu's concubines—so I say: eight sharp people and we can do it too. Why must you fix on one brand? Your threshold, the cost of signing, mainly comes from different languages. Right.

**R3 (29:57)** — [unclear] no good; look, you cannot.

**R1 (30:00)** — Did you look at it? Did you show it to someone else? Do not do that—explain it clearly. This enthusiasm is like [unclear].

**R4 (30:12)** — —is very impressive.

**R1 (30:13)** — Right, right—a bit like what is called... in Transformers. These—this is the hydraulic system. You and I—I do not know whether their site is still not running.

**R4 (30:29)** — Good.

**R1 (30:30)** — This is at—

**R4 (30:33)** — The maintenance plant.

**R2 (30:35)** — Yes, the Wuhu plant.

**R1 (30:41)** — This is enthusiasm—you have to see that this is a—

**R3 (30:44)** — The spring, this enthusiasm—on the spring side it looks as if no media is connected here.

**R1 (30:50)** — Do you have a video here? Do you know whether there is no video? It should be in there on my side, in our cloud drive—never mind, forget it. You get the general feel. We have fully automatic, semi-automatic and manual [lines] to suit different orders and scenarios. Some things at the development stage need manual adjustment; that is roughly what ours can do. This inspector. Play a video first, and add your most recent one.

**R1 (31:34)** — This video is also what we were talking about; you can have a look—this is only—

### 13. The research assistant, as described on the video (31:38–35:23)

**R5 (31:38)** — [unclear]

**R1 (31:40)** — This is what our [unclear: primary schoolers] say—today I want to show everyone.

**R1 (31:51)** — No need. Then, that is to say—

**R2 (31:54)** — He is just saying his—

**R1 (31:55)** — The English name is very high-end; it is called [unclear: "Rose John"].

**R2 (32:00)** — Look, I am going to Lhasa.

**R1 (32:02)** — Our [unclear: coiler]—this Rose Joyce will do.

**R2 (32:09)** — Ice-coiling.

**R1 (32:10)** — This one will do. It is actually a kind of mapping of us—of the whole company's [image]. All our things—this company is one problem. Because one production line of ours is also a skills-based agent.

**R1 (32:24)** — Then how do we carry it: is it for a scenario, or for an algorithm, or for the data, or to upgrade it? Through an ordinary—should be neural-network—kind of contract, how should we do it? That is roughly the set of ideas. These ideas need someone to help us actually implement them. But the ideas are like this, and some of them we are already practising.

**R2 (32:46)** — That is quite good.

**R5 (32:51)** — Send us the little assistant and the smart WeCom.

**R1 (32:54)** — This is our first generation; in fact it is knowledge management. Right.

**R5 (32:59)** — [note: video narration] It was developed independently by us together with university experts, on a local large model: an intelligent R&D collaboration platform, built for the engineers in the technology centre.

**R1 (33:08)** — [unclear] at present.

**R5 (33:09)** — [note: video narration] The core capability focuses on two directions: intelligent knowledge question-and-answer, and automatic generation of 3D and 2D drawings. A local large model plus retrieval-augmented generation plus natural-language parsing gives higher-quality vectorisation and comprehension of knowledge, significantly improving retrieval accuracy and the usefulness of answers. At the same time, an engineer only has to enter key parameters—spring, stabiliser bar—and a 3D or 2D drawing is generated in seconds; it can be edited online and exported directly to CATIA and NX for fine adjustment. So the R&D assistant not only greatly shortens the design cycle, it makes the company's knowledge assets actually flow, releases engineers from repetitive work, returns them to the source of innovation, and concentrates them on high-value R&D decisions and breakthroughs in core technology. The second, the smart WeCom, is already in use across the company. Last year we—

**R1 (34:17)** — In October we spent over two hundred yuan, but we—

**R5 (34:22)** — [note: video narration] The intelligent robot was built as the CCO series.

**R1 (34:24)** — The intelligent robot is one—

**R5 (34:26)** — [note: video narration] integrating process and knowledge services.

**R1 (34:29)** — In the end the response is high, or because it has already—a month ago, within a few hours, you could also—

**R5 (34:35)** — [note: video narration] —implement the intelligent summary function together with me.

**R1 (34:39)** — Right now inside it adds three boxes, adds one—every day we have [unclear] that can be raised.

**R4 (34:49)** — So the underlayer is all DeepSeek—or did I get that wrong?

**R5 (34:54)** — [note: video narration] We really feel you should release the intelligent table; every one of us has one inside.

**R1 (35:02)** — Automatic. What we commonly use now is Qwen—then I will go for an hour; when we need it there will be more messages. For example, in general—

**R5 (35:22)** — [note: video narration] And a picture.

**R1 (35:23)** — Video and so on. This bag, in theory, is for video, but in practice its image presentation is not good. Then Doubao—I think for life, including emotional value, it covers all of that. And there is Yuanbao. Am I not telling you that I scroll through a huge number of videos? But there is a stretch that may take more than five minutes.

### 14. Inventory queries and token spend (35:50–39:41)

**R2 (35:50)** — Have it summarise.

**R1 (35:51)** — Right, and have it summarise us. When I look at the summary and think it is worth it, we open it up and look.

**R4 (35:57)** — So which part of the company is involved here?

**R1 (36:00)** — Wait a moment; give this content later.

**R4 (36:03)** — Let me say something.

**R3 (36:05)** — Do you think it has already passed?

**R1 (36:07)** — All right, introduce again what we opened this week.

**R3 (36:11)** — In the end, we are also handling some earlier AI scenarios internally. For example, a package we have connected, or some of the inventory analysis we now use. Say we want to purchase today: the current raw-material warehouse, the recommended warehouse, and the product department's material inventory. I can take our experimental data, connect the previous production data into our group, and analyse it, including querying by hand on the [unclear] products. How to put it—if you want to know what my original [stock] is today, I just ask directly.

**R1 (36:47)** — His is not yet natural-language enough. You would want to say "the stock in my raw-material warehouse", and then you can trace further.

**R4 (37:00)** — This process. So through—

**R3 (37:01)** — Right, through understanding our requirement, and then querying according to the relevant entries in the data dictionary.

**R1 (37:09)** — Then ask it again. This one supports queuing, so I can ask it ten questions at once. Then the two of us go for coffee, and after coffee it is done; otherwise someone sits there waiting. Then you shoot another one—is it really not there? No, that is external modelling [unclear].

**R3 (37:39)** — So the relevant data are—

**R1 (37:42)** — Right, once it is in one list we can go on to understand more.

**R2 (37:46)** — How many tokens do you burn in a month now?

**R1 (37:50)** — There is also an electricity meter—that we did for energy management. And now we are thinking: you see, we only used to consume power; now we have started generating as well. So when we can feed it back in reverse—you see, when it turns around—right, this is [unclear]. Good, this student here. Hello, hello.

**R2 (38:17)** — I do not know what this is either—never mind.

**R1 (38:21)** — This is about the local teacher.

**R2 (38:23)** — This is my colleague.

**R1 (38:24)** — Same, the men. Hello—sorry, I am late; sorry, I am late. I was already—this is my classmate from university.

**R2 (38:42)** — [laughs]

**R1 (38:44)** — We have been listening to [unclear]. This is our list—look at this token. Why is today's—this is the newly opened one, right? Yesterday, tomorrow, they will all go up. On Monday, when we opened it, it was 6.2 dollars; after about a quarter of an hour of asking it became—eight-point-something, 8.8, 9-point-something.

**R3 (39:14)** — Roughly, when it was not yet—later, at the first inventory [query], it reached—

**R1 (39:18)** — 8.28, right. And roughly how many do we use in a day now?

**R3 (39:23)** — Right now, because we are testing, we have not actually done any detailed statistics. Because sometimes it may be—

**R2 (39:31)** — Two—on yours there is something, not thirty days.

**R3 (39:36)** — It is a total, right, and also a daily trend. Yes.

**R1 (39:41)** — So [a colleague], look—who among us is willing, who can help us stand it up—maybe, like photovoltaics, this [unclear: tariff].

### 15. Token structure, not token volume (39:50–41:20)

**R2 (39:50)** — That is a good line of thought.

**R1 (39:52)** — It is a very good one. I think in future we will change our consumers. For example, if I say that 20 per cent of my money each year goes on Moutai, I am showing off; my consumption is high. But if I say 20 per cent of my money goes on [unclear: tokens], then the structure is different.

**R1 (40:17)** — Right, and then he said he spent ten million decorating a house, or spent ten million on something. I think, of course—if my ten million on tokens is all asking what the weather is today and whether it will rain this afternoon—right, that is allowed too, right? Because I am looking at the input-output ratio and the value of my token use. Because the backend you can see—our backend can capture this.

**R2 (40:44)** — Use the results to analyse—

**R1 (40:46)** — product quality, precision, how it is. And then look, by user, at the frequency and so on. Once we understand through these—

**R2 (40:56)** — This is what [a colleague] is good at—[a colleague] is good at doing this. It is like he made ten million today selling a house, but I made ten million selling tokens: a completely different feeling.

**R1 (41:06)** — This is what a technology company should be thinking hard about. In fact, since we say we are analysing [unclear] from the product side, the talent experience, at 40 per cent—on top of that we should build a new—

**R2 (41:20)** — way of thinking. Right, right—completely different. Yes.

### 16. Continuous thought (41:29–45:28)

**R1 (41:29)** — Last time I pulled strings and attended the Congress of Chinese Mathematicians. This time—[unclear] a source of yours—there was a forum, and the theme was "maths for AI, AI for maths". After I had seen it—this year we needed last year—after seeing it, I felt that with this AI, whatever the product, it must have our enterprise. Over there it is like this: the front door, this is a problem. On the same day the maths—they call it the graduate entrance examination in maths; a group of people worked it out, a group of AIs were doing it, we were not doing it. The highest was still [unclear: Germany's]. I have a version—say 138 was not done, 150 was not done. And the second: for example the top 130 people, the lowest also had 120; the lowest, the ones who just turned up, twenty of them, the lowest also had one. And another point is that it is related to the depth of thought. So when you have only a seven-second memory, you are a fish, you are in the fish's world.

**R1 (42:57)** — So sustained thinking: say ten minutes—roughly how much of a child, the IQ of a certain child; if you can go continuously for one hour, you might be, say, at the level of a high-school student; if you can think continuously for, say, three hours, we might be talking about a doctoral student; if you can think for a lifetime, you might succeed. That is how it is. So he took continuous thinking time and did an analysis with it.

**R1 (43:29)** — Second, he took the whole thing—he set a very hard problem, a bunch of people who could not do it, only the AI people—like our maths problems—and he found a striking similarity: the sorrow is the same as with people, really. They say these were not designed by him. But surely someone had that idea; but the thinking he produces now, and why—and he is a person who learns extremely well. What does that mean? When doing a problem he first produces an intuition—roughly this machine—then presses a button and does it; when he has finished, [he asks] "have you handed in? are you slow?"—I will switch to another way of thinking and do it again, and do it again. I have done it—not only is the answer different, of course it is different—so he starts checking. And I think the first one is logically a bit like automation; he says I will teach the second one, the whole team. I think this is actually a good student.

**R2 (44:37)** — That is what I once asked many teachers: what is a good student? The dean of the Chinese University of Hong Kong—he was in accounting. He said, I have never thought about this question. Because at the time I was still a doctoral student; I asked him and he gave me one [answer]. He said most students, when they do things—I met him every week; after the meeting he would go and do it a bit better. A good student is: once 1-2-3 is done, when he comes to see me next week he will have finished it. Then he said, there are few, but there really are very good students: 1-2-3 assigned, next week he comes and says, teacher, I think there are four ways—say, several ways—to do it, I tried all four, and I found one is better; based on that way there may be several ways to do it. Now I want to ask you, which do you think is wrong? That is how it is.

**R1 (45:28)** — That is it. Actually, from the point of view of IQ, it follows a normal distribution. How many people face what kind of distribution—that is basically not necessarily true. It is some ways of thinking, and one's own—[unclear: the craft of the work itself].

### 17. Series into parallel (45:45–51:06)

**R2 (45:45)** — So listening to you just now, I think this is a problem we in organisation and management will probably face very soon. It is not a question of token volume; it is a question of token structure. That is, what I use these tokens for, which of them are high quality—like what we do now, this high-quality information, this data, and cost—it is actually a question of judging quality and value. And who judges value better is what shows up as who does the problems better. Right—when the value judgement is not particularly good, it is a bit like: the easy ones I can all do, the hard ones I cannot do any of, the bonus question I will never do. But if you test me on easy questions, I can keep up with others—that is the feeling of the Shanghai school-leaving exam. But once it is the university entrance exam, it is different. Right, that is the process.

**R1 (46:38)** — Take our inventory: apart from that, we also use it in our OA—approvals, leave requests, purchase requisitions. Right, and in fact this too should be process re-engineering.

**R1 (46:55)** — Right—because why must it be this kind of cascaded or hierarchical technology? Why can it not be assessed in parallel, turning series into parallel? An example: why can we not form a group? In my group I want to buy something, and nobody objects. Why must I go to him, and he says what—and in the end the general manager signs off at a certain level? In fact, why can we not [do it differently]?

**R1 (47:28)** — This is how it goes. Now there are all kinds of conditional approvals. I say: any application that [a colleague] brings, I approve—that is also a team approval. Why can we not do that? That way you can use the machine. Where do you want to go—his side. This member-approval thing we have now: I can also say, let my robot approve it all for me; after it has approved, I say, how much of what type did you save me, how much did you save, and how many were above what amount. When you highlight it for me and I find a mistake, then I just modify the logic of his skill. Leave requests—yours, I do not need that, right? I say: tell me today who did not come in, and then I look at the reason; if I want to trace it I trace it, if not, knowing who did not come is enough.

**R2 (48:25)** — In our academic research I have seen it put this way: the reason series cannot become parallel is one particular thing—

**R1 (48:35)** — People are not ready.

**R2 (48:37)** — Right—because people's cognitive structure for a task is: I always do this first, then that, then that. AI may not have that.

**R1 (48:46)** — But people have no specialism. And another thing: if we assume that everyone in the posts now is—then all the more we should have them tell the AI their rules, hand over their skills—he is coordinating anyway. Because with that, the person after him inherits from him. For example, if I take over his work, that thing is lifted up to me. Right—I can stand on the giant's shoulders and do one more. At least he can guarantee that I reach 60. Then from 60 to 80 I have to learn myself; 80 to 100 depends on [unclear] whether we are no good.

**R2 (49:22)** — And there is cost in that handover you just described, and it is very hard to quantify now. So the result is that when AI does this—because I do work design myself, I find its basic logic is a two-dimensional quadrant: the horizontal axis is the time spent on the task, the vertical axis is the skill required. Usually when we do, say, 1-2-3, the bottleneck is always where the time is short but the skill is high, because an ordinary AI cannot do that. To solve the problem, AI usually does a forced pass: it merges everything that takes long but competes little into one step and hands it to a person at the end. The high-skill part is the conditional approval you just described—you do all the front part for me, and unless it really concerns me, do not disturb me. Because the cost of invoking that skill is simply too high. Right, that is the situation at present.

**R2 (50:38)** — And once that problem arises, that is the logic it has to solve. In that process I have to break all the tasks into pieces. After breaking them up, look at what takes a lot of time, and the cost. But people do not think about things that way. Because when people think about it, it is usually: the previous incumbent gave it to me, I see how others do it, and then I think that is how it is done. So our granularity is not necessarily as fine as AI's—that is the first thing.

**R2 (51:06)** — Second, after breaking it up, the thing you imagine is not necessarily something I can understand anew. So it is harder. And the third is that leadership and management become harder. If it really is done according to this logic later, then when a leader asks, why did you not look at the front part, why did you only look here—and then slowly, if you want to assign responsibility, or rebalance—it is actually harder.

### 18. Atomising the process with industrial engineering (51:33–56:27)

**R1 (51:33)** — That is why we now study industrial engineering: to find a way to make people and machines use the same language—at least one logic. [A colleague], I have sent you a WeCom message; open it and look—do you not have WeCom?

**R1 (51:54)** — Now, from the process side too, we use industrial-engineering methods to atomise it. Then consider: this thing can be merged, merged and moved to department A; that class of things is handed to AI or to the system; and there is a class of things you must strengthen—because you cannot do it, that creates insulation. An example—is this interesting? Look at the slices; we still have to slice, [unclear].

**R2 (52:21)** — We also had our terminology just now—the two days of work, actually—

**R1 (52:25)** — This is our ordinary process. Right, if you work on this problem it is actually meaningless.

**R2 (52:29)** — Right.

**R1 (52:31)** — Because there is nothing further down. Then open up each block again—this is very hard to solve, the time and workload problem. If you open each block again using industrial-engineering methods—for example, he has three Ws. There is waste; this is work; moving is work; this is work. Right—open these things up. And then switch dimension: for example, this is a cancellation; switch dimension again and open it up. Open the machine directly—for example, label 1-2-3-4-5-6-7-8—and keep using these opened-up things. We said before: these people, this is another department—understand—this is me, this is another department. For example, AI—or once you have all this sorted, close it in, and then you can rebuild on that basis. The core is here.

**R2 (53:36)** — If you hit a bottleneck in the middle, you cannot get around it.

**R1 (53:42)** — I know. I think that is quite normal—I will improve the rest. Because if you cannot get around it and must solve it, that is perfectionism. My idealism is fast iteration: better than now. Better than now is teaching; of course the cost, this input-output ratio, is controllable. So we now keep eating breakfast. Because today's technology is immature—right, that does not mean it will be tomorrow's bottleneck. Today's immaturity represents tomorrow's problem.

**R2 (54:11)** — For example, taking this one as an example, how would you optimise it?

**R1 (54:17)** — Right, right.

**R2 (54:19)** — Or with a "wait" work [note: the wait state in the process map].

**R1 (54:22)** — Right? The CE preliminary analysis—the CE process is a complex process; it needs to wait for the software to finish running [unclear: the spring plant], then it takes time to investigate the licence and the insufficient work quantity. You see, like this—it takes a long time. So why wait? You just queue up several instructions and go and do other things. It does not mean your series [is blocked]; you have other projects at the same time, other things at the same time, right?

**R1 (54:49)** — And look: after we did it like that, is it not equivalent to sharing my licence? Right. I manage by people: whenever someone is idle, I queue a task into it. That way everyone—put a university student in and do it together—yes, naturally I have [unclear] and that is right. Right.

**R2 (55:13)** — Very large.

**R1 (55:15)** — In fact you can score it. Everything that is difficult—you must first divide it, then score it; it seems it cannot be recorded—change to a passive way, change the recording method. So then you think about splitting it. So now, talking about atomised analysis, I think it is quite worthwhile.

**R1 (55:30)** — We can atomise cost too. For example, a few years ago someone asked us: if your factory does no work at all for a day, roughly how many [kWh] do you need? We did not know these things; now we can know such a thing. For example, if you do not produce for a day, roughly how many degrees [of electricity]? You think 200 degrees is reasonable, right? Right, there should be. When we checked, we found it should actually be 300 degrees. Of those 100 degrees, that part should be used very quickly. For example—you said our emergency exit, should it not have a bulb? That bulb is fast; then let us solve the safety problems together.

**R1 (56:16)** — Right, at least the compliance problem—but not necessarily a risk. But the compliance problem—later we found, say, it should be 280 degrees, right? And another 20 degrees: I found it was an air conditioner, no problem.

**R1 (56:27)** — An example. Then through this atomisation you can actually solve a lot of problems. For example, his input does produce output. Our organisation now—our enabling organisation—this is what I especially like to talk about with him. Not like some students, who come and just press tasks on you all day. He is quite good. Inside his [unclear: pressing on the summit of the Himalayas there is a nest of spirits]; most likely nobody can—

### 19. The enabling organisation and the R&D transition (56:55–01:00:04)

**R2 (56:55)** — Can carry it over and see.

**R1 (56:58)** — But if there are supply bags along the way, then everyone can join in. So we only need, in our path planning, to let it produce part of the value—has value, and through such fast iteration, I do not know.

**R2 (57:17)** — What kind of body makes sense—excuse me, let me ask: right now, if I look at the two product engineers above, actually normal working time and waiting time are not much, and the work path is relatively determined; will this part be where AI substitutes fastest?

**R1 (57:36)** — Why would I do that? I want our R&D to transform. Because I find that our R&D—this high-value work, you mentioned what people used to do—right now I am forcing them to transform. Because these are all children. Right, we may not—at our age we cannot look deeply into it—so you just take it; my children, after all, I have to let them—even after we retire or leave, their rice bowl can keep going. So now this is what I focus on analysing; my next step, my technical team, the focus is with the intelligence team. Right, there is no choice, because what you used to do—for me—

**R2 (58:20)** — has a threshold.

**R1 (58:21)** — Now for me there is no threshold. Right—how do you think? As long as it is based on UG or his DM, once my rules are maintained well, this drawing does not need you. Right, I can use about one-twentieth of the time, and it succeeds; and the stability is better than a person's.

**R1 (58:40)** — I will tell you: last summer we went to a company in Wuxi. Its name is very grand, and it set a very grand and great goal. It uses IPA on top of UG. I feel he did not tell us—not the underlayer; I feel it is RPA plus AI; AI has no rules. Then the IPA takes a menu on the phone and fills the two input fields in. Then it naturally starts modelling and draws the mould drawing; in the end a person makes fine adjustments—for example, what we just said, where quantification is harder, or a harder operation. In the end he achieved a 90 per cent saving of time.

**R1 (59:27)** — Second point: his first-pass success rate reached 98 per cent, because you know that [unclear: above 20 per cent]—people put things in the wrong place. A person—for example, the person doing the movement—for example, he is afraid you do not know where interference can occur. Right, an example: an experienced person places it, and then—this position, what are you doing? Then when you see the person, something is produced that leads to [unclear]. So, deducting the human factor, a hundred per cent—so this should not be [unclear].

**R4 (01:00:02)** — Mainly it is your afternoon.

**R2 (01:00:04)** — There is also a meeting, right?

*[Recording ends.]*

## Notes for analysis

- The opening passage (00:00) is the interview's clearest statement of what replaces headcount as a control: a written response standard, plus a diagnosis of which failure it was—slackness, materials, or hands.
- R1 repeatedly separates a number from its use: the KPI as a check (04:26), the 200-versus-300 kWh baseline (55:30), the token counter running from 6.2 to 8.8 dollars (38:44). Code for how a measure becomes actionable only once someone owns the comparison.
- The hand-and-face analogy (07:35) and "we can only monitor equipment, not yet the parts" (06:43) mark where R1 himself places the boundary of machine observation.
- The exchange at 46:55–48:46 is the one place where R1 and R2 co-produce an argument about approval design; R1's "people are not ready" and "people have no specialism" (48:35, 48:46) are the counter-claims to his own proposal to turn series into parallel.
- Token structure versus token volume (39:52–41:29, 45:45) links consumption to value judgement, but R1 offers no measurement of it—only the ratio he wants to be able to see.
- Large stretches are a factory walkthrough with screen-sharing; deictic turns ("this one", "over there") lose their referent and should not be quoted without the surrounding passage.

