# Thematic index

A coding aid, not a finding. Each entry points to a block of talk, not to a claim the authors endorse. Ranges give
the block; where a specific moment matters, a timestamp is given.

Citation form: `(R1, INT-01, 00:41:12)` or `(INT-02, §18)`.

---

## A. Claim versus fact: who did it, who deserved it

| Locator | What is there |
|---|---|
| INT-03 §1, 01:18–02:31 | "We mistake the platform for our own capability." Shanghai as inherited advantage, read as personal merit. |
| INT-04 §2, 01:30–01:57 | The same error in generational form: a cohort that took a social dividend as its own role, and failed when the dividend moved. |
| INT-01 §1, 00:00–03:19 | Claiming the general manager's chair reluctantly; reading the context before acting, because a report arrives already carrying the reporter's interest. |
| INT-01 §9, 01:04:44–01:14:26 | What survives a firm: lineage, sponsorship, and transfers that leave no record in the receiving organisation. |

## B. Evaluation versus work

| Locator | What is there |
|---|---|
| INT-02 §3, 04:26–06:43 | "The KPI as a check, not a whip": how a shop-floor metric is meant to be used, and what happens when it is used as a verdict. |
| INT-02 §1, 00:00–01:28 | The fifteen-minute rule: response time as the unit the firm actually manages. |
| INT-01 §6, 36:24–41:31 | Compensation argued as buying capability rather than rewarding output; the firm's own account of why pay is a strategy variable. |
| INT-04 §3, 02:50–03:38 | Shutting a company, then re-engaging it as a subcontractor under explicit terms: a judgment applied to a team rather than to persons. |

## C. What is recorded, and what disappears

| Locator | What is there |
|---|---|
| INT-02 §2, 02:01–04:22 | What the screen shows, and what it does not: tags, breaks, shift status, and the categories the system has available. |
| INT-02 §14, 35:50–39:41 | Inventory queries and token spend: the firm measuring its own measurement cost. |
| INT-03 §2, 06:07 | Help that went unacknowledged, and stopped. The clearest passage in the corpus on reciprocity that leaves no trace. |
| INT-01 §5, 26:34–36:20 | The handover problem: what is lost when a task moves between people, and why the loss is invisible in output. |

## D. Task decomposition and substitution

| Locator | What is there |
|---|---|
| INT-02 §18, 51:33–56:27 | Atomising the process with industrial engineering, then deciding which atoms an agent can take. |
| INT-02 §17, 45:45–51:06 | Turning a series of steps into parallel work: the reorganisation that precedes any productivity gain. |
| INT-01 §8, 56:36–01:04:15 | Digitising the spring, and the problem of releasing people whose work the digitisation replaces. |

## E. Capability, skill, and their depreciation

| Locator | What is there |
|---|---|
| INT-01 §4, 16:13–26:17 | Control theory as a model of skill: fire first, observe, correct. Capability as an iterative loop rather than a stock. |
| INT-01 §12, 01:40:07–01:57:28 | Knees, six fingers, and whether a machine should imitate a body: what a capability is *for*. |
| INT-02 §16, 41:29–45:28 | "Continuous thought" and the difference between a model that answers and one that keeps working. |

## F. Technology choice: compensatory and untimely

| Locator | What is there |
|---|---|
| INT-01 §2, 04:09–08:59 | Inappropriate technology: capital and fashion selecting tools that are not the best fit, and the firm's own history of localisation. |
| INT-01 §3, 09:29–15:15 | Cheap tools, cheap teams, and the Bosch question: why a German firm that localised R&D early did better than one that did not. |
| INT-02 §6, 10:19–13:19 | Cheap hardware in an age of involution: buying capability at falling prices. |

## G. Authority, organisation, and who decides

| Locator | What is there |
|---|---|
| INT-02 §8, 15:39–17:04 | The joint venture and the chairman's leverage. |
| INT-02 §10, 19:42–22:33 | Top-level design, and the difficulty of selling a second-generation system to a first-generation organisation. |
| INT-04 §4, 04:03–05:36 | Sixty-eight days: what remains controllable when the environment stops being legible. |

## H. Human and machine at the point of production

| Locator | What is there |
|---|---|
| INT-02 §12, 27:06–31:34 | The enclosure, the robots, and a video: how automation is presented to visitors versus how it runs. |
| INT-01 §11, 01:26:22–01:40:05 | Robots that fall over; incubation; what a machine must be able to do before it can be given a task. |

## I. Strategy, losses, and the argument about the future

| Locator | What is there |
|---|---|
| INT-04 §1, 00:03–01:06 | What the word "China" in the firm's name obliges. |
| INT-04 §2, 01:06–02:23 | The loss-making years and the first-principles turn. |
| INT-01 §7, 42:03–55:51 | Ten per cent of profit from outside cars, and where the spring actually sits in a vehicle. |
| INT-01 §10, 01:14:34–01:26:19 | Customers as a portfolio; air suspension; the aftermarket. |

## J. Service quality and system discipline

| Locator | What is there |
|---|---|
| INT-03 §2, 03:35–04:35 | German punctuality as a property of a procedure rather than a person. |
| INT-03 §3, 07:48–09:51 | A recent counter-example: one-to-one handover on the Chinese rail network, and R1's reaction to it. |

---

## Passages to handle with care

| Locator | Why |
|---|---|
| INT-01 11:26 | The "second generation / my sister / department head" passage collapses into repetition; the argument resumes at 12:01. |
| INT-01 29:23–29:58 | Metaverse sequence; the object of the sentence is unrecoverable. |
| INT-01 01:47:43–01:52:30 | The Xinyu plan's character-etymology argument does not survive translation; the pun is described, not carried. |
| INT-02 27:06–31:34 | Plant-walk stretch: demonstratives point at objects outside the transcript. |
| INT-02 31:38–35:23 | Company video voice-over (R5); not speech by an interviewee. |
| INT-03 10:04–10:10 | Conversation breaks off as the group moves; the final turn is fragmentary. |
| INT-04 01:06 | "1840" is used as the name of a loss-making period; the year cannot be verified. |
